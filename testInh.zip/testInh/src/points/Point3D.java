package points;

public class Point3D extends Point
{
	private int z;
//***********************************************
	public Point3D() //Default Constructor
	{
		super();
		z=0;
	}
//***********************************************
	public Point3D(int x, int y,int z) //None Default Constructor
	{
		super(x,y);
		this.z = z;
	}
//***********************************************
		public Point3D(Point3D p) //Copy Constructor 
		{
			super((Point)p);
			this.z = p.getZ();
		}
//***********************************************
	public int getZ() {
		return z;
	}
//***********************************************
	public void setZ(int z) {
		this.z = z;
	}
//***********************************************
	@Override
	public String toString() {
		return "Point3D [z=" + z + ", " + super.toString() + "]";
	}
//***********************************************
	@Override
	public double distance(Point p)
	{
		System.out.print("Distance in 3D");
		return Math.sqrt(Math.pow(getX()-p.getX(), 2)+Math.pow(getY()-p.getY(), 2)+Math.pow(z-((Point3D)p).z,2));
	}
//***********************************************
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Point3D)) {
			return false;
		}
		Point3D other = (Point3D) obj;
		if(!(super.equals(obj)))
		  return false;
		if(z!=other.z)
		{
			return false;}
		
		return true;
	}
	


}