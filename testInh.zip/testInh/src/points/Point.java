package points;

public class Point
{
	private int x;
	private int y;
	
	public Point() //Default Constructor
	{
		x=y=0;
	}
//***********************************************
	public Point(int x, int y) //None Default Constructor
	{
		this.x = x;
		this.y = y;
	}
//***********************************************
	public Point(Point p) //Copy Constructor
	{
		this.x = p.getX();
		this.y = p.getY();
	}
//***********************************************
	public int getX()
	{
		return x;
	}
//***********************************************
	public void setX(int x)
	{
		this.x = x;
	}
//***********************************************
	public int getY()
	{
		return y;
	}
//***********************************************
	public void setY(int y)
	{
		this.y = y;
	}
//***********************************************
	@Override
	public String toString() {
		return "Point [x=" + x + ", y=" + y + "]";
	}
//***********************************************
@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Point)) {
			return false;
		}
		Point other = (Point) obj;
		if (x != other.x) {
			return false;
		}
		if (y != other.y) {
			return false;
		}
		return true;
	}
//***********************************************

public double distance(Point p)
{
	
	return Math.sqrt(Math.pow(x-p.x, 2)+Math.pow(y-p.y, 2));
}
//***********************************************

	

}

