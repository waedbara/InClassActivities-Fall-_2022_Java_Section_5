/**
 * 
 */
/**
 * @author Samer.Suleiman
 *
 */
module testInh {
}