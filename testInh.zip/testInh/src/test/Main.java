package test;
import points.*;
import shapes.Circle;
public class Main 
{

	public static void main(String[] args) 
	{
		Point p1,p2,p3;
		p1=new Point(2,6);
		p2=new Point(1,3);
		p3=new Point(3,8);
		Point3D p4=new Point3D(0,0,0);
		Point3D p5=new Point3D(2,5,6);
		Point3D p6=new Point3D(p5); //test Copy Constructor for Point3D
		System.out.println("p6:"+p6);
		System.out.println("p6==p5:"+p6.equals(p5));//test override method equal for Point3D
		System.out.println(p1); //test override toString in Point
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p6.equals(p5));//test override method equal for Point
		Circle c=new Circle(p1,p2);//create object of circle
		System.out.println("Center of the Circle "+ p1);
		System.out.printf("Radius of the Circle=%.2f%n", c.getRadius());
		System.out.printf("Area of Circle=%.2f%n",c.calcArea());
		System.out.printf("Perimeter of Circle=%.2f%n", c.calcPeri());
		//P1 act as Point Object and as Point3D Object and call the override method distance and toString
		System.out.printf("distance between p1,p2 in 2D=%.2f%n",p1.distance(p2)); //P1 here is Point Object as declared
		System.out.println(p1.equals(p2));
		p1=p4;//Implicit casting reference variable of point the super points to it subclass reference variable
		System.out.println(p1);
		System.out.printf(" between p1,p5=%.2f%n",p1.distance(p5));
/*Following code will be complied, because of explicit casting but failed at run time
 * reference variable of sub class point3d will not point to an object of super calss Point
 */
		
		/*p5=(Point3D) p2;
		System.out.println(p5.distance(p3));*/
	}
}
