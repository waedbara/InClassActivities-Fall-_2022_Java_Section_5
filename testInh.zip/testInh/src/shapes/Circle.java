package shapes;

import points.Point;


public class Circle 
{
	private	Point p1; //Composition
	private	Point p2; //Composition

	public double getRadius()
	{
		return p1.distance(p2);
	}
	//*********************************************
	public Circle(Point p1, Point p2)
	{
		this.p1=new Point(p1.getX(),p1.getY());
		this.p2=new Point(p2.getX(),p2.getY());
	}
	//*********************************************
	public double calcArea()
	{
		return Math.pow(getRadius(),2)*Math.PI;
	}
	//*********************************************
	public double calcPeri() 
	{
		return 2*getRadius()*Math.PI;
	}
	//*********************************************
	@Override
	protected void finalize() throws Throwable
	{
		System.out.println("end of object"+this.getClass());
	}
	
}


